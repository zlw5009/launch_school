require 'sinatra'
require 'sinatra/reloader'
require 'tilt/erubis'
require 'pry'

configure do
  enable :sessions
  set :session_secret, 'secret'
  set :erb, :escape_html => true
end

helpers do
  def empty_fields?
    @empty_fields == nil || @empty_fields.empty?
  end

  def display_credit_card(cc_num)
    masked_card = cc_num.scan(/.{1,4}/).join("-")
    cc_num.gsub(/.{1,12}\b/, '*')
  end
end

before do
  session[:payment] ||= {}
end

get '/' do
  redirect '/payments/create'
end

get "/payments/create" do
  erb :form
end

post '/payments/create' do
  session[:payment] = {"first name" => params[:first],
    "last name" => params[:last],
    "card number" => params[:card_number],
    "expiration date" => params[:exp_date],
    "cvv" => params[:cvv]
  }

  @empty_fields = session[:payment].select { |k, v| v.size < 1 }

  if session[:payment]["card number"].size < 16
    session[:message] = "Invalid Card Number"
  elsif @empty_fields.empty?
    session[:message] = "Thank you for your payment."
    redirect "/payments"
  end

  erb :form
end

get '/payments' do
  @date = DateTime::now
  erb :payments
end
